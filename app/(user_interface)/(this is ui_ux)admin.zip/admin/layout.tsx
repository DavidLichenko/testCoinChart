"use client";

import React, {useEffect, useMemo} from "react";
import Link from "next/link";
import {usePathname, useRouter} from "next/navigation";
import {motion} from "framer-motion";
import {
    BarChart3,
    CreditCard,
    MessageCircle,
    Settings as SettingsIcon,
    Shield,
    TrendingUp,
    Users,
    Wallet as WalletIcon,
} from "lucide-react";
import {useAuth} from "@/components/auth-provider";
import {Card, CardContent} from "@/components/ui/card";

type SectionKey =
    | "dashboard"
    | "users"
    | "team"
    | "transactions"
    | "orders"
    | "verification"
    | "chat"
    | "settings";

type Section = {
    key: SectionKey;
    label: string;
    href: string;
    icon: React.ComponentType<{ className?: string }>;
    ownerOnly?: boolean;
};

const SECTIONS: Section[] = [
    { key: "dashboard", label: "Dashboard", href: "/admin", icon: BarChart3 },
    { key: "users", label: "Users", href: "/admin/users", icon: Users },
    { key: "team", label: "Team", href: "/admin/team", icon: Users },
    { key: "wallets", label: "Wallets", href: "/admin/wallets", icon: WalletIcon },
    {
        key: "transactions",
        label: "Trades",
        href: "/admin/transactions",
        icon: TrendingUp,
    },
    {
        key: "orders",
        label: "Orders",
        href: "/admin/orders",
        icon: CreditCard,
    },
    {
        key: "verification",
        label: "Verification",
        href: "/admin/verification",
        icon: Shield,
    },
    { key: "chat", label: "Chat", href: "/admin/chat", icon: MessageCircle },
    {
        key: "settings",
        label: "Settings",
        href: "/admin/settings",
        icon: SettingsIcon,
        ownerOnly: true,
    },
];

export default function AdminLayout({
                                        children,
                                    }: {
    children: React.ReactNode;
}) {
    const { user, loading } = useAuth();
    const router = useRouter();
    const pathname = usePathname();

    // guard
    useEffect(() => {
        if (loading) return;

        if (!user) {
            router.push("/");
            return;
        }

        const isAdmin =
            user.role === "OWNER" ||
            user.role === "CR_MANAGMENT" ||
            user.role === "TEAMLEAD";

        if (!isAdmin) {
            router.push("/dashboard");
        }
    }, [user, loading, router]);

    if (loading || !user) {
        return null;
    }

    const isOwner = user.role === "OWNER";

    const sections = useMemo(
        () => SECTIONS.filter((s) => !s.ownerOnly || isOwner),
        [isOwner]
    );

    const activeSection =
        sections.find((s) =>
            s.key === "dashboard" ? pathname === "/admin" : pathname.startsWith(s.href)
        ) ?? sections[0];

    return (
        <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35 }}
            className="min-h-screen bg-gradient-to-br from-[#050215] via-[#120423] to-[#050215] text-slate-50"
        >
            <div className="mx-auto flex max-w-screen-2xl flex-col gap-6 px-4 py-6 md:flex-row md:py-8 lg:px-0">
                {/* LEFT: sidebar */}
                <aside className="md:w-64 md:flex-shrink-0 space-y-4">
                    {/* Admin header card */}
                    <Card className="bg-slate-950/80 border-slate-800/80 shadow-sm">
                        <CardContent className="p-4 flex flex-col gap-3">
                            <div className="flex items-center gap-3">
                                <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-purple-500 via-indigo-500 to-sky-500 shadow-lg shadow-purple-500/40">
                                    <BarChart3 className="h-5 w-5 text-white" />
                                </div>
                                <div className="min-w-0">
                                    <p className="text-xs font-semibold text-slate-300">
                                        Admin Panel
                                    </p>
                                    <p className="truncate text-sm font-semibold">
                                        {user.name || user.email}
                                    </p>
                                    <p className="text-[11px] text-slate-400 mt-0.5">
                                        Role:{" "}
                                        <span className="uppercase tracking-wide">
                      {user.role}
                    </span>
                                    </p>
                                </div>
                            </div>

                            <div className="mt-1 rounded-xl bg-slate-900/80 px-3 py-2 text-[11px] text-slate-300">
                                <p className="text-slate-400">Current section</p>
                                <p className="font-medium text-purple-200">
                                    {activeSection.label}
                                </p>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Desktop vertical nav */}
                    <Card className="hidden bg-slate-950/80 border-slate-800/80 shadow-sm md:block">
                        <CardContent className="p-2">
                            <nav className="flex flex-col gap-1">
                                {sections.map((section) => {
                                    const Icon = section.icon;
                                    const active = section.key === activeSection.key;
                                    return (
                                        <Link
                                            key={section.key}
                                            href={section.href}
                                            className={`group flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-xs transition-all ${
                                                active
                                                    ? "bg-gradient-to-r from-purple-600/90 to-indigo-500/90 text-white shadow-md shadow-purple-500/30"
                                                    : "text-slate-200 hover:bg-slate-900/80"
                                            }`}
                                        >
                                            <span className="flex items-center gap-2">
                                            <Icon
                                                className={`h-4 w-4 ${
                                                    active ? "text-white" : "text-slate-400 group-hover:text-slate-100"}`}
                                            />
                                            <span className="font-medium">{section.label}</span>
                                            </span>
                                        </Link>
                                    );
                                })}
                            </nav>
                        </CardContent>
                    </Card>

                    {/* Mobile chips nav */}
                    <Card className="bg-slate-950/80 border-slate-800/80 shadow-sm md:hidden">
                        <CardContent className="flex gap-2 overflow-x-auto p-2">
                            {sections.map((section) => {
                                const Icon = section.icon;
                                const active = section.key === activeSection.key;
                                return (
                                    <Link
                                        key={section.key}
                                        href={section.href}
                                        className={`flex flex-shrink-0 items-center gap-1 rounded-full px-3 py-2 text-[11px] transition ${
                                            active
                                                ? "bg-purple-600 text-white shadow-sm"
                                                : "bg-slate-900 text-slate-200"
                                        }`}
                                    >
                                        <Icon className="h-3.5 w-3.5" />
                                        <span>{section.label}</span>
                                    </Link>
                                );
                            })}
                        </CardContent>
                    </Card>
                </aside>

                {/* RIGHT: content */}
                <main className="flex-1 space-y-4">
                    <div className="mb-2">
                        <h1 className="text-2xl md:text-3xl font-bold tracking-tight">
                            Admin · {activeSection.label}
                        </h1>
                        <p className="mt-1 text-sm text-slate-400">
                            Manage users, trades, verification and platform settings in one
                            place.
                        </p>
                    </div>

                    {children}
                </main>
            </div>
        </motion.div>
    );
}
